CREATE DATABASE IF NOT EXISTS hostel_cms;
USE hostel_cms;

CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('STUDENT','WARDEN','ADMIN') NOT NULL,
    room_number VARCHAR(20),
    phone_number VARCHAR(15),
    active BOOLEAN DEFAULT TRUE,
    created_at DATETIME,
    updated_at DATETIME
);

CREATE TABLE IF NOT EXISTS complaints (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    category ENUM('MAINTENANCE','FOOD','WIFI','HYGIENE','ELECTRICITY','OTHER') NOT NULL,
    priority ENUM('LOW','NORMAL','URGENT') NOT NULL,
    status ENUM('OPEN','IN_PROGRESS','RESOLVED','CLOSED') DEFAULT 'OPEN',
    assigned_to VARCHAR(100),
    resolution_note TEXT,
    student_id BIGINT,
    created_at DATETIME,
    updated_at DATETIME,
    FOREIGN KEY (student_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS status_history (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    complaint_id BIGINT,
    previous_status ENUM('OPEN','IN_PROGRESS','RESOLVED','CLOSED'),
    new_status ENUM('OPEN','IN_PROGRESS','RESOLVED','CLOSED') NOT NULL,
    changed_by VARCHAR(100),
    note TEXT,
    changed_at DATETIME,
    FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE
);

INSERT INTO users (name,email,password,role,room_number,phone_number,active,created_at,updated_at) VALUES
('Admin User','admin@hostel.edu','$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy','ADMIN',NULL,'9000000001',TRUE,NOW(),NOW()),
('Dr. P. Reddy','warden@hostel.edu','$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy','WARDEN','Office','9000000002',TRUE,NOW(),NOW()),
('Rahul Sharma','rahul@hostel.edu','$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy','STUDENT','204','9000000003',TRUE,NOW(),NOW()),
('Priya Nair','priya@hostel.edu','$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy','STUDENT','118','9000000004',TRUE,NOW(),NOW());
