# Hostel Complaint Management System

Full-stack web app — Spring Boot (Java 17) + React.js + MySQL

---

## 📁 Project Structure

```
hostel-cms/
├── backend/          ← Spring Boot app
├── frontend/         ← React app
└── database/
    └── schema.sql    ← MySQL setup + seed data
```

---

## 🚀 Setup Instructions

### Prerequisites
- Java 17+
- Node.js 18+
- MySQL 8+
- Maven 3.8+

---

### 1. Database Setup

Open MySQL and run:
```sql
source /path/to/hostel-cms/database/schema.sql
```

Or in terminal:
```bash
mysql -u root -p < database/schema.sql
```

Update `backend/src/main/resources/application.properties` if your MySQL credentials differ:
```properties
spring.datasource.username=root
spring.datasource.password=root
```

---

### 2. Start Backend (Spring Boot)

```bash
cd backend
mvn spring-boot:run
```

Backend runs on: **http://localhost:8080**

---

### 3. Start Frontend (React)

```bash
cd frontend
npm install
npm start
```

Frontend runs on: **http://localhost:3000**

> The frontend proxies `/api` calls to `http://localhost:8080` automatically.

---

## 🔐 Demo Login Credentials

All passwords: `password123`

| Role    | Email                | Notes           |
|---------|----------------------|-----------------|
| Admin   | admin@hostel.edu     | Full access     |
| Warden  | warden@hostel.edu    | Manage complaints |
| Student | rahul@hostel.edu     | Room 204        |
| Student | priya@hostel.edu     | Room 118        |

---

## 🗺️ API Endpoints

### Auth (Public)
| Method | URL                  | Description     |
|--------|----------------------|-----------------|
| POST   | /api/auth/login      | Login           |
| POST   | /api/auth/register   | Register        |

### Student (ROLE_STUDENT)
| Method | URL                           | Description         |
|--------|-------------------------------|---------------------|
| POST   | /api/student/complaints       | File complaint      |
| GET    | /api/student/complaints/my    | My complaints       |

### Warden (ROLE_WARDEN / ROLE_ADMIN)
| Method | URL                                | Description     |
|--------|------------------------------------|-----------------|
| GET    | /api/warden/complaints             | All complaints  |
| GET    | /api/warden/complaints/{id}        | Complaint detail|
| PUT    | /api/warden/complaints/{id}/status | Update status   |

### Admin (ROLE_ADMIN)
| Method | URL                         | Description     |
|--------|-----------------------------|-----------------|
| GET    | /api/admin/analytics        | Stats           |
| GET    | /api/admin/users            | All users       |
| PUT    | /api/admin/users/{id}/toggle | Toggle active  |
| DELETE | /api/admin/users/{id}       | Delete user     |
| DELETE | /api/admin/complaints/{id}  | Delete complaint|

---

## 🧱 Tech Stack

| Layer     | Technology                        |
|-----------|-----------------------------------|
| Backend   | Java 17, Spring Boot 3.2, Spring Security |
| Auth      | JWT (jjwt 0.12)                   |
| Database  | MySQL 8, Spring Data JPA, Hibernate |
| Frontend  | React 18, Axios                   |
| Build     | Maven (backend), npm (frontend)   |

---

## 📊 Features

**Student**
- Register / Login
- File complaints with category & priority
- Track complaint status with timeline

**Warden**
- View all complaints with filters & search
- Assign to maintenance staff
- Update status with notes

**Admin**
- Everything Warden can do
- Manage users (activate/deactivate/delete)
- View analytics dashboard (by category, by status)
