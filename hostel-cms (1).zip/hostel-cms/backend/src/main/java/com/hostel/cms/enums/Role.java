package com.hostel.cms.enums;
public enum Role { STUDENT, WARDEN, ADMIN }
