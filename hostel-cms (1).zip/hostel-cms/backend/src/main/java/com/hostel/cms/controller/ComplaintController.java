package com.hostel.cms.controller;
import com.hostel.cms.dto.*;
import com.hostel.cms.service.ComplaintService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class ComplaintController {
    @Autowired private ComplaintService complaintService;

    @PostMapping("/student/complaints")
    public ResponseEntity<ComplaintResponse> create(@RequestBody ComplaintRequest req, Authentication auth) {
        return ResponseEntity.ok(complaintService.create(req, auth.getName()));
    }

    @GetMapping("/student/complaints/my")
    public ResponseEntity<List<ComplaintResponse>> getMyComplaints(Authentication auth) {
        return ResponseEntity.ok(complaintService.getMyComplaints(auth.getName()));
    }

    @GetMapping("/warden/complaints")
    public ResponseEntity<List<ComplaintResponse>> getAllComplaints() {
        return ResponseEntity.ok(complaintService.getAllComplaints());
    }

    @GetMapping("/warden/complaints/{id}")
    public ResponseEntity<ComplaintResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(complaintService.getById(id));
    }

    @PutMapping("/warden/complaints/{id}/status")
    public ResponseEntity<ComplaintResponse> updateStatus(
            @PathVariable Long id, @RequestBody UpdateStatusRequest req, Authentication auth) {
        return ResponseEntity.ok(complaintService.updateStatus(id, req, auth.getName()));
    }

    @GetMapping("/admin/analytics")
    public ResponseEntity<Map<String, Object>> getAnalytics() {
        return ResponseEntity.ok(complaintService.getAnalytics());
    }

    @DeleteMapping("/admin/complaints/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        complaintService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
