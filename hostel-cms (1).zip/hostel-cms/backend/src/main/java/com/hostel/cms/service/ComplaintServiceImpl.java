package com.hostel.cms.service;
import com.hostel.cms.dto.*;
import com.hostel.cms.entity.*;
import com.hostel.cms.enums.*;
import com.hostel.cms.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class ComplaintServiceImpl implements ComplaintService {
    @Autowired private ComplaintRepository complaintRepo;
    @Autowired private UserRepository userRepo;
    @Autowired private StatusHistoryRepository historyRepo;

    @Override
    public ComplaintResponse create(ComplaintRequest req, String email) {
        User student = userRepo.findByEmail(email).orElseThrow();
        Complaint c = Complaint.builder()
                .title(req.getTitle()).description(req.getDescription())
                .category(Category.valueOf(req.getCategory().toUpperCase()))
                .priority(Priority.valueOf(req.getPriority().toUpperCase()))
                .student(student).build();
        complaintRepo.save(c);
        StatusHistory h = StatusHistory.builder()
                .complaint(c).newStatus(ComplaintStatus.OPEN)
                .changedBy(email).note("Complaint registered").build();
        historyRepo.save(h);
        return toDto(c);
    }

    @Override
    public List<ComplaintResponse> getMyComplaints(String email) {
        User user = userRepo.findByEmail(email).orElseThrow();
        return complaintRepo.findByStudentIdOrderByCreatedAtDesc(user.getId())
                .stream().map(this::toDto).toList();
    }

    @Override
    public List<ComplaintResponse> getAllComplaints() {
        return complaintRepo.findAllByOrderByCreatedAtDesc().stream().map(this::toDto).toList();
    }

    @Override
    public ComplaintResponse getById(Long id) {
        return toDto(complaintRepo.findById(id).orElseThrow());
    }

    @Override
    public ComplaintResponse updateStatus(Long id, UpdateStatusRequest req, String updaterEmail) {
        Complaint c = complaintRepo.findById(id).orElseThrow();
        ComplaintStatus prev = c.getStatus();
        ComplaintStatus next = ComplaintStatus.valueOf(req.getStatus().toUpperCase());
        c.setStatus(next);
        if (req.getAssignedTo() != null) c.setAssignedTo(req.getAssignedTo());
        if (req.getNote() != null) c.setResolutionNote(req.getNote());
        complaintRepo.save(c);
        StatusHistory h = StatusHistory.builder()
                .complaint(c).previousStatus(prev).newStatus(next)
                .changedBy(updaterEmail).note(req.getNote()).build();
        historyRepo.save(h);
        return toDto(c);
    }

    @Override
    public void delete(Long id) { complaintRepo.deleteById(id); }

    @Override
    public Map<String, Object> getAnalytics() {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("total", complaintRepo.count());
        map.put("open", complaintRepo.countByStatus(ComplaintStatus.OPEN));
        map.put("inProgress", complaintRepo.countByStatus(ComplaintStatus.IN_PROGRESS));
        map.put("resolved", complaintRepo.countByStatus(ComplaintStatus.RESOLVED));
        map.put("closed", complaintRepo.countByStatus(ComplaintStatus.CLOSED));
        Map<String,Long> byCat = new LinkedHashMap<>();
        complaintRepo.countByEachCategory().forEach(r -> byCat.put(r[0].toString(), (Long)r[1]));
        map.put("byCategory", byCat);
        Map<String,Long> byStatus = new LinkedHashMap<>();
        complaintRepo.countByEachStatus().forEach(r -> byStatus.put(r[0].toString(), (Long)r[1]));
        map.put("byStatus", byStatus);
        map.put("totalStudents", userRepo.countByRole(Role.STUDENT));
        return map;
    }

    private ComplaintResponse toDto(Complaint c) {
        ComplaintResponse r = new ComplaintResponse();
        r.setId(c.getId()); r.setTitle(c.getTitle()); r.setDescription(c.getDescription());
        r.setCategory(c.getCategory().name()); r.setPriority(c.getPriority().name());
        r.setStatus(c.getStatus().name()); r.setAssignedTo(c.getAssignedTo());
        r.setResolutionNote(c.getResolutionNote());
        if (c.getStudent() != null) {
            r.setStudentName(c.getStudent().getName());
            r.setStudentEmail(c.getStudent().getEmail());
            r.setRoomNumber(c.getStudent().getRoomNumber());
        }
        r.setCreatedAt(c.getCreatedAt()); r.setUpdatedAt(c.getUpdatedAt());
        return r;
    }
}
