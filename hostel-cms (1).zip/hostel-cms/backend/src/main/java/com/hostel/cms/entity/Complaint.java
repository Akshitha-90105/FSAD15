package com.hostel.cms.entity;

import com.hostel.cms.enums.*;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity @Table(name="complaints")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Complaint {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @Column(nullable=false) private String title;
    @Column(columnDefinition="TEXT") private String description;
    @Enumerated(EnumType.STRING) private Category category;
    @Enumerated(EnumType.STRING) private Priority priority;
    @Enumerated(EnumType.STRING) @Builder.Default private ComplaintStatus status = ComplaintStatus.OPEN;
    private String assignedTo;
    private String resolutionNote;
    @ManyToOne(fetch=FetchType.LAZY) @JoinColumn(name="student_id") private User student;
    @OneToMany(mappedBy="complaint",cascade=CascadeType.ALL,fetch=FetchType.LAZY) private List<StatusHistory> statusHistory;
    @Column(updatable=false) private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    @PrePersist void prePersist(){ createdAt=LocalDateTime.now(); updatedAt=LocalDateTime.now(); }
    @PreUpdate void preUpdate(){ updatedAt=LocalDateTime.now(); }
}
