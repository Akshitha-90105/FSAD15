package com.hostel.cms.controller;
import com.hostel.cms.entity.User;
import com.hostel.cms.enums.Role;
import com.hostel.cms.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin/users")
public class UserController {
    @Autowired private UserRepository userRepo;

    @GetMapping
    public ResponseEntity<List<User>> getAll() { return ResponseEntity.ok(userRepo.findAll()); }

    @GetMapping("/students")
    public ResponseEntity<List<User>> getStudents() {
        return ResponseEntity.ok(userRepo.findByRole(Role.STUDENT));
    }

    @PutMapping("/{id}/toggle")
    public ResponseEntity<Map<String,String>> toggleActive(@PathVariable Long id) {
        User u = userRepo.findById(id).orElseThrow();
        u.setActive(!u.isActive());
        userRepo.save(u);
        return ResponseEntity.ok(Map.of("status", u.isActive() ? "active" : "inactive"));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        userRepo.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
