package com.hostel.cms.enums;
public enum Priority { LOW, NORMAL, URGENT }
