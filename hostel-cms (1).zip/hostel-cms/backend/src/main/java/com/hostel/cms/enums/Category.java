package com.hostel.cms.enums;
public enum Category { MAINTENANCE, FOOD, WIFI, HYGIENE, ELECTRICITY, OTHER }
