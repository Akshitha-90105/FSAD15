package com.hostel.cms.entity;

import com.hostel.cms.enums.ComplaintStatus;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity @Table(name="status_history")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class StatusHistory {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch=FetchType.LAZY) @JoinColumn(name="complaint_id") private Complaint complaint;
    @Enumerated(EnumType.STRING) private ComplaintStatus previousStatus;
    @Enumerated(EnumType.STRING) private ComplaintStatus newStatus;
    private String changedBy;
    private String note;
    private LocalDateTime changedAt;
    @PrePersist void prePersist(){ changedAt=LocalDateTime.now(); }
}
