package com.hostel.cms.dto;
import lombok.Data;
@Data
public class RegisterRequest {
    private String name;
    private String email;
    private String password;
    private String role;
    private String roomNumber;
    private String phoneNumber;
}
