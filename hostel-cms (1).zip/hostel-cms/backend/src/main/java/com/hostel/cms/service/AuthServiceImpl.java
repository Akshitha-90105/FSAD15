package com.hostel.cms.service;
import com.hostel.cms.dto.*;
import com.hostel.cms.entity.User;
import com.hostel.cms.enums.Role;
import com.hostel.cms.repository.UserRepository;
import com.hostel.cms.security.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthServiceImpl implements AuthService {
    @Autowired private AuthenticationManager authManager;
    @Autowired private UserRepository userRepo;
    @Autowired private PasswordEncoder encoder;
    @Autowired private JwtUtils jwtUtils;

    @Override
    public AuthResponse login(AuthRequest req) {
        Authentication auth = authManager.authenticate(
                new UsernamePasswordAuthenticationToken(req.getEmail(), req.getPassword()));
        String token = jwtUtils.generateToken(auth);
        User user = userRepo.findByEmail(req.getEmail()).orElseThrow();
        return new AuthResponse(token, user.getName(), user.getEmail(),
                user.getRole().name(), user.getRoomNumber());
    }

    @Override
    public AuthResponse register(RegisterRequest req) {
        if (userRepo.existsByEmail(req.getEmail()))
            throw new RuntimeException("Email already in use");
        User user = User.builder()
                .name(req.getName()).email(req.getEmail())
                .password(encoder.encode(req.getPassword()))
                .role(Role.valueOf(req.getRole().toUpperCase()))
                .roomNumber(req.getRoomNumber())
                .phoneNumber(req.getPhoneNumber())
                .build();
        userRepo.save(user);
        Authentication auth = authManager.authenticate(
                new UsernamePasswordAuthenticationToken(req.getEmail(), req.getPassword()));
        String token = jwtUtils.generateToken(auth);
        return new AuthResponse(token, user.getName(), user.getEmail(),
                user.getRole().name(), user.getRoomNumber());
    }
}
