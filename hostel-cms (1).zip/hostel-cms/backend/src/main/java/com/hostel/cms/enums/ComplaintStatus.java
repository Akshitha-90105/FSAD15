package com.hostel.cms.enums;
public enum ComplaintStatus { OPEN, IN_PROGRESS, RESOLVED, CLOSED }
