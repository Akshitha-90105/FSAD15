package com.hostel.cms.service;
import com.hostel.cms.dto.*;
public interface AuthService {
    AuthResponse login(AuthRequest request);
    AuthResponse register(RegisterRequest request);
}
