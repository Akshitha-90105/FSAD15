package com.hostel.cms.service;
import com.hostel.cms.dto.*;
import java.util.List;
import java.util.Map;
public interface ComplaintService {
    ComplaintResponse create(ComplaintRequest req, String email);
    List<ComplaintResponse> getMyComplaints(String email);
    List<ComplaintResponse> getAllComplaints();
    ComplaintResponse getById(Long id);
    ComplaintResponse updateStatus(Long id, UpdateStatusRequest req, String updaterEmail);
    void delete(Long id);
    Map<String, Object> getAnalytics();
}
