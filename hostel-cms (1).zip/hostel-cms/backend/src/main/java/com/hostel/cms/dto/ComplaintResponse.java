package com.hostel.cms.dto;
import lombok.Data;
import java.time.LocalDateTime;
@Data
public class ComplaintResponse {
    private Long id;
    private String title;
    private String description;
    private String category;
    private String priority;
    private String status;
    private String assignedTo;
    private String resolutionNote;
    private String studentName;
    private String studentEmail;
    private String roomNumber;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
