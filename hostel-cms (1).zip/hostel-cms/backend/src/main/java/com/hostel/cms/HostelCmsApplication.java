package com.hostel.cms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HostelCmsApplication {
    public static void main(String[] args) {
        SpringApplication.run(HostelCmsApplication.class, args);
    }
}
