package com.hostel.cms.dto;
import lombok.Data;
@Data
public class UpdateStatusRequest {
    private String status;
    private String assignedTo;
    private String note;
}
