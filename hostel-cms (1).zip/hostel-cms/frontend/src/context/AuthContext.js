import React, { createContext, useContext, useState } from 'react';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem('cms_user')); } catch { return null; }
  });

  const login = (userData) => {
    localStorage.setItem('cms_user', JSON.stringify(userData));
    localStorage.setItem('cms_token', userData.token);
    setUser(userData);
  };

  const logout = () => {
    localStorage.removeItem('cms_user');
    localStorage.removeItem('cms_token');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
