import axios from 'axios';

const api = axios.create({ baseURL: '/api' });

api.interceptors.request.use(cfg => {
  const token = localStorage.getItem('cms_token');
  if (token) cfg.headers.Authorization = `Bearer ${token}`;
  return cfg;
});

api.interceptors.response.use(
  r => r,
  err => {
    if (err.response?.status === 401) {
      localStorage.removeItem('cms_user');
      localStorage.removeItem('cms_token');
      window.location.href = '/';
    }
    return Promise.reject(err);
  }
);

export default api;

// Auth
export const login    = (data) => api.post('/auth/login', data);
export const register = (data) => api.post('/auth/register', data);

// Student
export const createComplaint  = (data) => api.post('/student/complaints', data);
export const getMyComplaints  = ()     => api.get('/student/complaints/my');

// Warden
export const getAllComplaints = ()          => api.get('/warden/complaints');
export const getComplaintById = (id)       => api.get(`/warden/complaints/${id}`);
export const updateStatus     = (id, data) => api.put(`/warden/complaints/${id}/status`, data);

// Admin
export const getAnalytics = ()     => api.get('/admin/analytics');
export const getAllUsers   = ()     => api.get('/admin/users');
export const toggleUser   = (id)   => api.put(`/admin/users/${id}/toggle`);
export const deleteUser   = (id)   => api.delete(`/admin/users/${id}`);
export const deleteComplaint = (id)=> api.delete(`/admin/complaints/${id}`);
