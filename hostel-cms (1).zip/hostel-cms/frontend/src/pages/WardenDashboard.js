import React, { useEffect, useState } from 'react';
import { getAllComplaints } from '../api';
import { StatCard, StatusBadge, PriorityBadge, CategoryBadge, formatDate, Spinner } from '../components/Helpers';

export default function WardenDashboard({ setPage }) {
  const [complaints, setComplaints] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getAllComplaints().then(r => setComplaints(r.data)).finally(() => setLoading(false));
  }, []);

  if (loading) return <Spinner />;

  const open     = complaints.filter(c => c.status === 'OPEN').length;
  const progress = complaints.filter(c => c.status === 'IN_PROGRESS').length;
  const resolved = complaints.filter(c => c.status === 'RESOLVED').length;
  const urgent   = complaints.filter(c => c.priority === 'URGENT').length;
  const recent   = complaints.slice(0, 8);

  return (
    <>
      <div className="stats-grid">
        <StatCard label="Total"       value={complaints.length} sub="All complaints" color="c-blue"   />
        <StatCard label="Open"        value={open}              sub="Needs attention" color="c-red"    />
        <StatCard label="In Progress" value={progress}          sub="Being handled"  color="c-amber"  />
        <StatCard label="Resolved"    value={resolved}          sub="Closed"         color="c-green"  />
      </div>
      {urgent > 0 && (
        <div style={{ background: '#fee2e2', border: '1px solid #fca5a5', borderRadius: 10, padding: '12px 16px', marginBottom: 18, fontSize: 13, color: '#991b1b', display: 'flex', alignItems: 'center', gap: 8 }}>
          ⚠️ <strong>{urgent} urgent complaint{urgent > 1 ? 's' : ''}</strong> need immediate attention.
          <button className="btn btn-sm btn-danger" style={{ marginLeft: 'auto' }} onClick={() => setPage('all-complaints')}>View All</button>
        </div>
      )}
      <div className="card">
        <div className="card-header">
          <h3>Recent Complaints</h3>
          <button className="btn btn-sm btn-primary" onClick={() => setPage('all-complaints')}>View All</button>
        </div>
        {recent.length === 0 ? (
          <div className="empty"><div className="icon">✅</div><p>No complaints at the moment.</p></div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>ID</th><th>Title</th><th>Student</th><th>Category</th><th>Priority</th><th>Status</th><th>Filed</th></tr></thead>
              <tbody>
                {recent.map(c => (
                  <tr key={c.id}>
                    <td style={{ color: '#94a3b8', fontSize: 11 }}>#{c.id}</td>
                    <td style={{ fontWeight: 500 }}>{c.title}</td>
                    <td style={{ fontSize: 12 }}>{c.studentName}</td>
                    <td><CategoryBadge category={c.category} /></td>
                    <td><PriorityBadge priority={c.priority} /></td>
                    <td><StatusBadge status={c.status} /></td>
                    <td style={{ color: '#64748b', fontSize: 12 }}>{formatDate(c.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}
