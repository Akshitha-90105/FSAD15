import React, { useEffect, useState } from 'react';
import { getAllComplaints, updateStatus, deleteComplaint } from '../api';
import { StatusBadge, PriorityBadge, CategoryBadge, formatDate, Spinner } from '../components/Helpers';
import { useAuth } from '../context/AuthContext';

const STAFF = ['Suresh Kumar', 'Ravi Teja', 'Cleaning Team', 'Electrician Team', 'Plumber', 'IT Support'];
const STATUSES = ['OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'];

function UpdateModal({ c, onClose, onSaved }) {
  const [form, setForm] = useState({ status: c.status, assignedTo: c.assignedTo || '', note: '' });
  const [loading, setLoading] = useState(false);
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = async () => {
    setLoading(true);
    try { await updateStatus(c.id, form); onSaved(); onClose(); }
    catch { alert('Update failed.'); }
    finally { setLoading(false); }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h3>Update: #{c.id} — {c.title}</h3>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        <div style={{ marginBottom: 12, padding: '10px 14px', background: '#f8fafc', borderRadius: 8, border: '1px solid #e2e8f0', fontSize: 13, color: '#374151' }}>
          {c.description}
        </div>
        <div className="detail-grid" style={{ marginBottom: 16 }}>
          <div className="detail-item"><div className="dl">Student</div><div className="dv">{c.studentName}</div></div>
          <div className="detail-item"><div className="dl">Room</div><div className="dv">{c.roomNumber || '—'}</div></div>
        </div>
        <div className="form-group">
          <label>Status</label>
          <select value={form.status} onChange={e => set('status', e.target.value)}>
            {STATUSES.map(s => <option key={s} value={s}>{s.replace('_',' ')}</option>)}
          </select>
        </div>
        <div className="form-group">
          <label>Assign To</label>
          <select value={form.assignedTo} onChange={e => set('assignedTo', e.target.value)}>
            <option value="">— Unassigned —</option>
            {STAFF.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        <div className="form-group">
          <label>Note / Resolution</label>
          <textarea value={form.note} onChange={e => set('note', e.target.value)} placeholder="Add update note..." rows={3} />
        </div>
        <div className="form-actions">
          <button className="btn btn-primary" onClick={handleSave} disabled={loading}>{loading ? 'Saving...' : '💾 Save Update'}</button>
          <button className="btn" onClick={onClose}>Cancel</button>
        </div>
      </div>
    </div>
  );
}

export default function AllComplaints() {
  const { user } = useAuth();
  const [complaints, setComplaints] = useState([]);
  const [loading, setLoading]       = useState(true);
  const [filter, setFilter]         = useState('ALL');
  const [search, setSearch]         = useState('');
  const [selected, setSelected]     = useState(null);

  const load = () => {
    setLoading(true);
    getAllComplaints().then(r => setComplaints(r.data)).finally(() => setLoading(false));
  };

  useEffect(load, []);

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this complaint?')) return;
    await deleteComplaint(id);
    load();
  };

  if (loading) return <Spinner />;

  const filtered = complaints
    .filter(c => filter === 'ALL' || c.status === filter)
    .filter(c => !search || c.title.toLowerCase().includes(search.toLowerCase()) || c.studentName?.toLowerCase().includes(search.toLowerCase()));

  return (
    <>
      {selected && <UpdateModal c={selected} onClose={() => setSelected(null)} onSaved={load} />}

      <div className="search-bar">
        <span>🔍</span>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by title or student name..." />
      </div>
      <div className="filter-row">
        {['ALL','OPEN','IN_PROGRESS','RESOLVED','CLOSED'].map(s => (
          <span key={s} className={`chip ${filter === s ? 'active' : ''}`} onClick={() => setFilter(s)}>
            {s.replace('_', ' ')} ({s === 'ALL' ? complaints.length : complaints.filter(c => c.status === s).length})
          </span>
        ))}
      </div>
      <div className="card">
        {filtered.length === 0 ? (
          <div className="empty"><div className="icon">📭</div><p>No complaints found.</p></div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr><th>ID</th><th>Title</th><th>Student</th><th>Room</th><th>Category</th><th>Priority</th><th>Status</th><th>Filed</th><th>Actions</th></tr>
              </thead>
              <tbody>
                {filtered.map(c => (
                  <tr key={c.id}>
                    <td style={{ color: '#94a3b8', fontSize: 11 }}>#{c.id}</td>
                    <td style={{ fontWeight: 500, maxWidth: 180 }}>{c.title}</td>
                    <td style={{ fontSize: 12 }}>{c.studentName}</td>
                    <td style={{ fontSize: 12 }}>{c.roomNumber || '—'}</td>
                    <td><CategoryBadge category={c.category} /></td>
                    <td><PriorityBadge priority={c.priority} /></td>
                    <td><StatusBadge status={c.status} /></td>
                    <td style={{ color: '#64748b', fontSize: 12 }}>{formatDate(c.createdAt)}</td>
                    <td>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button className="btn btn-sm btn-primary" onClick={() => setSelected(c)}>Update</button>
                        {user?.role === 'ADMIN' && (
                          <button className="btn btn-sm btn-danger" onClick={() => handleDelete(c.id)}>Del</button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}
