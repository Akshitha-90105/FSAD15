import React, { useState } from 'react';
import { createComplaint } from '../api';

const CATEGORIES = ['MAINTENANCE','FOOD','WIFI','HYGIENE','ELECTRICITY','OTHER'];
const PRIORITIES = ['LOW','NORMAL','URGENT'];

export default function NewComplaint({ setPage }) {
  const [form, setForm] = useState({ title: '', description: '', category: 'MAINTENANCE', priority: 'NORMAL' });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true); setError('');
    try {
      await createComplaint(form);
      setSuccess(true);
      setTimeout(() => setPage('my-complaints'), 1500);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to submit. Try again.');
    } finally { setLoading(false); }
  };

  return (
    <div className="card" style={{ maxWidth: 600 }}>
      <div className="card-header"><h3>📝 File a New Complaint</h3></div>
      <div className="card-body">
        {success && <div className="alert alert-success">✅ Complaint submitted successfully! Redirecting...</div>}
        {error   && <div className="alert alert-error">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Title *</label>
            <input value={form.title} onChange={e => set('title', e.target.value)} required placeholder="Brief description of the issue" />
          </div>
          <div className="form-row">
            <div className="form-group">
              <label>Category *</label>
              <select value={form.category} onChange={e => set('category', e.target.value)}>
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label>Priority *</label>
              <select value={form.priority} onChange={e => set('priority', e.target.value)}>
                {PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
          </div>
          <div className="form-group">
            <label>Description *</label>
            <textarea value={form.description} onChange={e => set('description', e.target.value)} required placeholder="Describe the issue in detail..." rows={4} />
          </div>
          <div className="form-actions">
            <button className="btn btn-primary" type="submit" disabled={loading}>
              {loading ? 'Submitting...' : '📤 Submit Complaint'}
            </button>
            <button className="btn" type="button" onClick={() => setPage('my-complaints')}>Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}
