import React, { useEffect, useState } from 'react';
import { getMyComplaints } from '../api';
import { StatCard, StatusBadge, PriorityBadge, CategoryBadge, formatDate, Spinner } from '../components/Helpers';

export default function StudentDashboard({ setPage }) {
  const [complaints, setComplaints] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getMyComplaints().then(r => setComplaints(r.data)).finally(() => setLoading(false));
  }, []);

  if (loading) return <Spinner />;

  const open  = complaints.filter(c => c.status === 'OPEN').length;
  const prog  = complaints.filter(c => c.status === 'IN_PROGRESS').length;
  const done  = complaints.filter(c => c.status === 'RESOLVED' || c.status === 'CLOSED').length;

  return (
    <>
      <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(3,1fr)' }}>
        <StatCard label="Total Filed"    value={complaints.length} sub="All time"          color="c-blue" />
        <StatCard label="Open / In Progress" value={open + prog}   sub="Awaiting resolution" color="c-amber" />
        <StatCard label="Resolved"       value={done}              sub="Closed issues"      color="c-green" />
      </div>

      <div className="card">
        <div className="card-header">
          <h3>My Complaints</h3>
          <button className="btn btn-primary btn-sm" onClick={() => setPage('new-complaint')}>+ New Complaint</button>
        </div>
        {complaints.length === 0 ? (
          <div className="empty"><div className="icon">📭</div><p>No complaints yet. File one!</p></div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>ID</th><th>Title</th><th>Category</th><th>Priority</th><th>Status</th><th>Date</th></tr></thead>
              <tbody>
                {complaints.map(c => (
                  <tr key={c.id}>
                    <td style={{ color: '#94a3b8', fontSize: 11 }}>#{c.id}</td>
                    <td style={{ fontWeight: 500 }}>{c.title}</td>
                    <td><CategoryBadge category={c.category} /></td>
                    <td><PriorityBadge priority={c.priority} /></td>
                    <td><StatusBadge status={c.status} /></td>
                    <td style={{ color: '#64748b', fontSize: 12 }}>{formatDate(c.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}
