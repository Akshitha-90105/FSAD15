import React, { useEffect, useState } from 'react';
import { getMyComplaints } from '../api';
import { StatusBadge, PriorityBadge, CategoryBadge, formatDate, formatDateTime, Spinner } from '../components/Helpers';

function ComplaintModal({ c, onClose }) {
  if (!c) return null;
  const steps = [
    { label: 'Registered', done: true, time: formatDateTime(c.createdAt) },
    { label: 'Assigned to Staff', done: !!c.assignedTo, time: c.assignedTo ? `Assigned to: ${c.assignedTo}` : 'Pending' },
    { label: 'In Progress', done: c.status === 'IN_PROGRESS' || c.status === 'RESOLVED' || c.status === 'CLOSED' },
    { label: 'Resolved', done: c.status === 'RESOLVED' || c.status === 'CLOSED', time: c.resolutionNote },
  ];

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h3>#{c.id} — {c.title}</h3>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        <div className="detail-grid">
          <div className="detail-item"><div className="dl">Status</div><div className="dv"><StatusBadge status={c.status}/></div></div>
          <div className="detail-item"><div className="dl">Priority</div><div className="dv"><PriorityBadge priority={c.priority}/></div></div>
          <div className="detail-item"><div className="dl">Category</div><div className="dv"><CategoryBadge category={c.category}/></div></div>
          <div className="detail-item"><div className="dl">Filed On</div><div className="dv">{formatDate(c.createdAt)}</div></div>
          {c.assignedTo && <div className="detail-item" style={{gridColumn:'1/-1'}}><div className="dl">Assigned To</div><div className="dv">{c.assignedTo}</div></div>}
        </div>
        <div className="form-group">
          <label>Description</label>
          <div style={{ fontSize: 13, color: '#374151', lineHeight: 1.6, background: '#f8fafc', padding: '10px 12px', borderRadius: 8, border: '1px solid #e2e8f0' }}>{c.description}</div>
        </div>
        <div style={{ marginTop: 16 }}>
          <div style={{ fontSize: 12, fontWeight: 500, color: '#374151', marginBottom: 10 }}>Status Timeline</div>
          <div className="timeline">
            {steps.map((s, i) => (
              <div className="tl-item" key={i}>
                <div className={`tl-dot ${s.done ? (i === steps.filter(x=>x.done).length - 1 ? 'active' : 'done') : 'pending'}`}></div>
                <div className="tl-text">
                  <div className="tl-title" style={{ color: s.done ? '#1a1a1a' : '#94a3b8' }}>{s.label}</div>
                  {s.time && <div className="tl-note">{s.time}</div>}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function MyComplaints() {
  const [complaints, setComplaints] = useState([]);
  const [loading, setLoading]       = useState(true);
  const [filter, setFilter]         = useState('ALL');
  const [selected, setSelected]     = useState(null);

  useEffect(() => {
    getMyComplaints().then(r => setComplaints(r.data)).finally(() => setLoading(false));
  }, []);

  if (loading) return <Spinner />;

  const statuses = ['ALL', 'OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'];
  const filtered = filter === 'ALL' ? complaints : complaints.filter(c => c.status === filter);

  return (
    <>
      {selected && <ComplaintModal c={selected} onClose={() => setSelected(null)} />}
      <div className="filter-row">
        {statuses.map(s => (
          <span key={s} className={`chip ${filter === s ? 'active' : ''}`} onClick={() => setFilter(s)}>
            {s === 'ALL' ? 'All' : s.replace('_', ' ')} {s === 'ALL' ? `(${complaints.length})` : `(${complaints.filter(c=>c.status===s).length})`}
          </span>
        ))}
      </div>
      <div className="card">
        {filtered.length === 0 ? (
          <div className="empty"><div className="icon">📭</div><p>No complaints found.</p></div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>ID</th><th>Title</th><th>Category</th><th>Priority</th><th>Status</th><th>Filed</th><th></th></tr></thead>
              <tbody>
                {filtered.map(c => (
                  <tr key={c.id}>
                    <td style={{ color: '#94a3b8', fontSize: 11 }}>#{c.id}</td>
                    <td style={{ fontWeight: 500 }}>{c.title}</td>
                    <td><CategoryBadge category={c.category} /></td>
                    <td><PriorityBadge priority={c.priority} /></td>
                    <td><StatusBadge status={c.status} /></td>
                    <td style={{ color: '#64748b', fontSize: 12 }}>{formatDate(c.createdAt)}</td>
                    <td><button className="btn btn-sm" onClick={() => setSelected(c)}>View</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}
