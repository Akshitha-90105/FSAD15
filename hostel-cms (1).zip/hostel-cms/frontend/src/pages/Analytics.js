import React, { useEffect, useState } from 'react';
import { getAnalytics } from '../api';
import { StatCard, Spinner } from '../components/Helpers';

function Bar({ label, value, max, color }) {
  const pct = max > 0 ? Math.round((value / max) * 100) : 0;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 10 }}>
      <div style={{ width: 100, fontSize: 12, color: '#64748b', textAlign: 'right', flexShrink: 0 }}>{label}</div>
      <div style={{ flex: 1, background: '#f1f5f9', borderRadius: 6, height: 28, overflow: 'hidden' }}>
        <div style={{ width: `${pct}%`, background: color, height: '100%', display: 'flex', alignItems: 'center', paddingLeft: 10, color: '#fff', fontSize: 12, fontWeight: 500, minWidth: value > 0 ? 36 : 0, transition: 'width 0.6s' }}>
          {value > 0 ? value : ''}
        </div>
      </div>
      <div style={{ width: 32, fontSize: 12, color: '#94a3b8' }}>{value}</div>
    </div>
  );
}

export default function Analytics() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getAnalytics().then(r => setData(r.data)).finally(() => setLoading(false));
  }, []);

  if (loading) return <Spinner />;

  const catColors = { MAINTENANCE:'#3b82f6', FOOD:'#ec4899', WIFI:'#10b981', HYGIENE:'#f59e0b', ELECTRICITY:'#eab308', OTHER:'#94a3b8' };
  const statusColors = { OPEN:'#3b82f6', IN_PROGRESS:'#f59e0b', RESOLVED:'#10b981', CLOSED:'#94a3b8' };
  const maxCat    = data.byCategory ? Math.max(...Object.values(data.byCategory), 1) : 1;
  const maxStatus = data.byStatus   ? Math.max(...Object.values(data.byStatus), 1)   : 1;

  return (
    <>
      <div className="stats-grid">
        <StatCard label="Total Complaints" value={data.total}         sub="All time"       color="c-blue"   />
        <StatCard label="Open"             value={data.open}          sub="Awaiting action" color="c-amber"  />
        <StatCard label="In Progress"      value={data.inProgress}    sub="Being handled"  color="c-purple"  />
        <StatCard label="Resolved"         value={data.resolved}      sub="Closed"         color="c-green"   />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        <div className="card">
          <div className="card-header"><h3>Complaints by Category</h3></div>
          <div className="card-body">
            {data.byCategory && Object.entries(data.byCategory).map(([k, v]) => (
              <Bar key={k} label={k} value={v} max={maxCat} color={catColors[k] || '#94a3b8'} />
            ))}
          </div>
        </div>

        <div className="card">
          <div className="card-header"><h3>Complaints by Status</h3></div>
          <div className="card-body">
            {data.byStatus && Object.entries(data.byStatus).map(([k, v]) => (
              <Bar key={k} label={k.replace('_',' ')} value={v} max={maxStatus} color={statusColors[k] || '#94a3b8'} />
            ))}
          </div>
        </div>
      </div>

      <div className="card" style={{ marginTop: 0 }}>
        <div className="card-header"><h3>System Summary</h3></div>
        <div className="card-body">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 16 }}>
            <div style={{ textAlign: 'center', padding: '16px 0' }}>
              <div style={{ fontSize: 36, fontWeight: 700, color: '#6366f1' }}>{data.totalStudents}</div>
              <div style={{ fontSize: 12, color: '#64748b', marginTop: 4 }}>Registered Students</div>
            </div>
            <div style={{ textAlign: 'center', padding: '16px 0', borderLeft: '1px solid #f1f5f9', borderRight: '1px solid #f1f5f9' }}>
              <div style={{ fontSize: 36, fontWeight: 700, color: '#10b981' }}>{data.resolved}</div>
              <div style={{ fontSize: 12, color: '#64748b', marginTop: 4 }}>Issues Resolved</div>
            </div>
            <div style={{ textAlign: 'center', padding: '16px 0' }}>
              <div style={{ fontSize: 36, fontWeight: 700, color: '#f59e0b' }}>{data.open + data.inProgress}</div>
              <div style={{ fontSize: 12, color: '#64748b', marginTop: 4 }}>Pending Resolution</div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
