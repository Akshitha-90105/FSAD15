import React, { useEffect, useState } from 'react';
import { getAllUsers, toggleUser, deleteUser } from '../api';
import { Spinner } from '../components/Helpers';

export default function UsersPage() {
  const [users, setUsers]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch]   = useState('');

  const load = () => {
    setLoading(true);
    getAllUsers().then(r => setUsers(r.data)).finally(() => setLoading(false));
  };

  useEffect(load, []);

  const handleToggle = async (id) => { await toggleUser(id); load(); };
  const handleDelete = async (id) => {
    if (!window.confirm('Delete this user? This cannot be undone.')) return;
    await deleteUser(id); load();
  };

  if (loading) return <Spinner />;

  const filtered = users.filter(u =>
    !search || u.name.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase())
  );

  const counts = { STUDENT: users.filter(u => u.role === 'STUDENT').length, WARDEN: users.filter(u => u.role === 'WARDEN').length, ADMIN: users.filter(u => u.role === 'ADMIN').length };

  return (
    <>
      <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(3,1fr)' }}>
        <div className="stat-card c-purple"><div className="label">Students</div><div className="value">{counts.STUDENT}</div></div>
        <div className="stat-card c-blue">  <div className="label">Wardens</div> <div className="value">{counts.WARDEN}</div></div>
        <div className="stat-card c-red">   <div className="label">Admins</div>  <div className="value">{counts.ADMIN}</div></div>
      </div>

      <div className="search-bar">
        <span>🔍</span>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search users by name or email..." />
      </div>

      <div className="card">
        <div className="card-header"><h3>All Users ({filtered.length})</h3></div>
        {filtered.length === 0 ? (
          <div className="empty"><div className="icon">👤</div><p>No users found.</p></div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Room</th><th>Phone</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody>
                {filtered.map(u => (
                  <tr key={u.id}>
                    <td style={{ fontWeight: 500 }}>{u.name}</td>
                    <td style={{ fontSize: 12, color: '#64748b' }}>{u.email}</td>
                    <td><span className={`badge badge-${u.role.toLowerCase()}`}>{u.role}</span></td>
                    <td style={{ fontSize: 12 }}>{u.roomNumber || '—'}</td>
                    <td style={{ fontSize: 12 }}>{u.phoneNumber || '—'}</td>
                    <td>
                      <span style={{ fontSize: 12, fontWeight: 500, color: u.active ? '#065f46' : '#991b1b' }}>
                        {u.active ? '● Active' : '● Inactive'}
                      </span>
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button className={`btn btn-sm ${u.active ? 'btn-warning' : 'btn-primary'}`} onClick={() => handleToggle(u.id)}>
                          {u.active ? 'Deactivate' : 'Activate'}
                        </button>
                        <button className="btn btn-sm btn-danger" onClick={() => handleDelete(u.id)}>Delete</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}
