import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { login as apiLogin, register as apiRegister } from '../api';

export default function LoginPage() {
  const { login } = useAuth();
  const [tab, setTab] = useState('login');
  const [form, setForm] = useState({ name:'', email:'', password:'', role:'STUDENT', roomNumber:'', phoneNumber:'' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(''); setLoading(true);
    try {
      const res = tab === 'login'
        ? await apiLogin({ email: form.email, password: form.password })
        : await apiRegister(form);
      login(res.data);
    } catch (err) {
      setError(err.response?.data?.message || 'Invalid credentials. Try again.');
    } finally { setLoading(false); }
  };

  return (
    <div className="auth-wrap">
      <div className="auth-card">
        <h1>🏠 Hostel CMS</h1>
        <p className="subtitle">Complaint Management System</p>

        <div className="auth-tabs">
          <button className={`auth-tab ${tab === 'login' ? 'active' : ''}`} onClick={() => setTab('login')}>Login</button>
          <button className={`auth-tab ${tab === 'register' ? 'active' : ''}`} onClick={() => setTab('register')}>Register</button>
        </div>

        {error && <div className="alert alert-error">{error}</div>}

        <form onSubmit={handleSubmit}>
          {tab === 'register' && (
            <>
              <div className="form-group">
                <label>Full Name</label>
                <input value={form.name} onChange={e => set('name', e.target.value)} required placeholder="Enter your name" />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Role</label>
                  <select value={form.role} onChange={e => set('role', e.target.value)}>
                    <option value="STUDENT">Student</option>
                    <option value="WARDEN">Warden</option>
                    <option value="ADMIN">Admin</option>
                  </select>
                </div>
                {form.role === 'STUDENT' && (
                  <div className="form-group">
                    <label>Room Number</label>
                    <input value={form.roomNumber} onChange={e => set('roomNumber', e.target.value)} placeholder="e.g. 204" />
                  </div>
                )}
              </div>
              <div className="form-group">
                <label>Phone Number</label>
                <input value={form.phoneNumber} onChange={e => set('phoneNumber', e.target.value)} placeholder="e.g. 9876543210" />
              </div>
            </>
          )}

          <div className="form-group">
            <label>Email</label>
            <input type="email" value={form.email} onChange={e => set('email', e.target.value)} required placeholder="you@hostel.edu" />
          </div>
          <div className="form-group">
            <label>Password</label>
            <input type="password" value={form.password} onChange={e => set('password', e.target.value)} required placeholder="••••••••" />
          </div>

          <button className="btn btn-primary" type="submit" disabled={loading} style={{ width: '100%', justifyContent: 'center', padding: '11px' }}>
            {loading ? 'Please wait...' : tab === 'login' ? 'Login' : 'Create Account'}
          </button>
        </form>

        <p style={{ fontSize: 12, color: '#94a3b8', marginTop: 18, textAlign: 'center' }}>
          Demo — student@hostel.edu / warden@hostel.edu / admin@hostel.edu · password: <strong>password123</strong>
        </p>
      </div>
    </div>
  );
}
