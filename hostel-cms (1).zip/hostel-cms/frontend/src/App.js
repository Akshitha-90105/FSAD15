import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import LoginPage        from './pages/LoginPage';
import Layout           from './components/Layout';
import StudentDashboard from './pages/StudentDashboard';
import NewComplaint     from './pages/NewComplaint';
import MyComplaints     from './pages/MyComplaints';
import AllComplaints    from './pages/AllComplaints';
import WardenDashboard  from './pages/WardenDashboard';
import Analytics        from './pages/Analytics';
import UsersPage        from './pages/UsersPage';

function AppRouter() {
  const { user } = useAuth();
  const [page, setPage] = useState('dashboard');

  if (!user) return <LoginPage />;

  const renderPage = () => {
    if (user.role === 'STUDENT') {
      switch (page) {
        case 'dashboard':      return <StudentDashboard setPage={setPage} />;
        case 'new-complaint':  return <NewComplaint     setPage={setPage} />;
        case 'my-complaints':  return <MyComplaints />;
        default:               return <StudentDashboard setPage={setPage} />;
      }
    }
    if (user.role === 'WARDEN') {
      switch (page) {
        case 'dashboard':     return <WardenDashboard setPage={setPage} />;
        case 'all-complaints':return <AllComplaints />;
        default:              return <WardenDashboard setPage={setPage} />;
      }
    }
    if (user.role === 'ADMIN') {
      switch (page) {
        case 'dashboard':     return <WardenDashboard setPage={setPage} />;
        case 'all-complaints':return <AllComplaints />;
        case 'users':         return <UsersPage />;
        case 'analytics':     return <Analytics />;
        default:              return <WardenDashboard setPage={setPage} />;
      }
    }
  };

  return (
    <Layout page={page} setPage={setPage}>
      {renderPage()}
    </Layout>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppRouter />
    </AuthProvider>
  );
}
