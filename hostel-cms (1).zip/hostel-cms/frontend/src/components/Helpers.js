import React from 'react';

export function Badge({ value, type }) {
  const v = (value || '').toLowerCase().replace(' ', '_');
  return <span className={`badge badge-${v}`}>{value}</span>;
}

export function StatusBadge({ status }) {
  return <Badge value={status} />;
}

export function PriorityBadge({ priority }) {
  return <Badge value={priority} />;
}

export function CategoryBadge({ category }) {
  return <Badge value={category} />;
}

export function formatDate(dt) {
  if (!dt) return '—';
  return new Date(dt).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function formatDateTime(dt) {
  if (!dt) return '—';
  return new Date(dt).toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export function StatCard({ label, value, sub, color = '' }) {
  return (
    <div className={`stat-card ${color}`}>
      <div className="label">{label}</div>
      <div className="value">{value}</div>
      {sub && <div className="sub">{sub}</div>}
    </div>
  );
}

export function Spinner() {
  return <div style={{ padding: 40, textAlign: 'center', color: '#94a3b8' }}>Loading...</div>;
}
