import React from 'react';
import { useAuth } from '../context/AuthContext';

const NAV = {
  STUDENT: [
    { id: 'dashboard',       label: '📊 Dashboard' },
    { id: 'new-complaint',   label: '➕ New Complaint' },
    { id: 'my-complaints',   label: '📋 My Complaints' },
  ],
  WARDEN: [
    { id: 'dashboard',       label: '📊 Dashboard' },
    { id: 'all-complaints',  label: '📥 All Complaints' },
  ],
  ADMIN: [
    { id: 'dashboard',       label: '📊 Dashboard' },
    { id: 'all-complaints',  label: '📥 All Complaints' },
    { id: 'users',           label: '👥 Manage Users' },
    { id: 'analytics',       label: '📈 Analytics' },
  ],
};

const TITLES = {
  dashboard: 'Dashboard', 'new-complaint': 'New Complaint',
  'my-complaints': 'My Complaints', 'all-complaints': 'All Complaints',
  users: 'Manage Users', analytics: 'Analytics',
};

export default function Layout({ page, setPage, children }) {
  const { user, logout } = useAuth();
  const nav = NAV[user?.role] || [];
  const initials = user?.name?.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();

  return (
    <div className="layout">
      <aside className="sidebar">
        <div className="sidebar-brand">
          <h2>Hostel CMS</h2>
          <p>Complaint Portal</p>
        </div>
        <nav className="sidebar-nav">
          {nav.map(n => (
            <div key={n.id} className={`nav-item ${page === n.id ? 'active' : ''}`} onClick={() => setPage(n.id)}>
              {n.label}
            </div>
          ))}
        </nav>
        <div>
          <button className="logout-btn" onClick={logout}>🚪 Logout</button>
          <div className="sidebar-footer">Hostel CMS v1.0</div>
        </div>
      </aside>

      <div className="main">
        <div className="topbar">
          <h1>{TITLES[page] || 'Dashboard'}</h1>
          <div className="topbar-right">
            <div className="user-info">
              <div className="name">{user?.name}</div>
              <div className="role-tag">{user?.role}{user?.roomNumber ? ` · Room ${user.roomNumber}` : ''}</div>
            </div>
            <div className="avatar">{initials}</div>
          </div>
        </div>
        <div className="content">{children}</div>
      </div>
    </div>
  );
}
