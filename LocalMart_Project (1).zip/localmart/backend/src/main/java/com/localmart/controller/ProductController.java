package com.localmart.controller;

import com.localmart.model.Product;
import com.localmart.model.User;
import com.localmart.repository.ProductRepository;
import com.localmart.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ProductController {

    @Autowired private ProductRepository productRepository;
    @Autowired private UserRepository userRepository;

    // ---- PUBLIC ENDPOINTS ----

    @GetMapping("/products/public/all")
    public ResponseEntity<?> getAllProducts() {
        return ResponseEntity.ok(productRepository.findByIsActiveTrue()
                .stream().map(this::toMap).collect(Collectors.toList()));
    }

    @GetMapping("/products/public/{id}")
    public ResponseEntity<?> getProduct(@PathVariable Long id) {
        return productRepository.findById(id)
                .map(p -> ResponseEntity.ok(toMap(p)))
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/products/public/search")
    public ResponseEntity<?> searchProducts(@RequestParam String keyword) {
        return ResponseEntity.ok(productRepository.searchProducts(keyword)
                .stream().map(this::toMap).collect(Collectors.toList()));
    }

    @GetMapping("/products/public/category/{category}")
    public ResponseEntity<?> getByCategory(@PathVariable String category) {
        return ResponseEntity.ok(productRepository.findByCategoryAndIsActiveTrue(category)
                .stream().map(this::toMap).collect(Collectors.toList()));
    }

    // ---- VENDOR ENDPOINTS ----

    @GetMapping("/vendor/products")
    public ResponseEntity<?> getVendorProducts(Authentication auth) {
        User vendor = userRepository.findByEmail(auth.getName()).orElseThrow();
        return ResponseEntity.ok(productRepository.findByVendorAndIsActiveTrue(vendor)
                .stream().map(this::toMap).collect(Collectors.toList()));
    }

    @PostMapping("/vendor/products")
    public ResponseEntity<?> addProduct(@RequestBody Map<String, Object> body, Authentication auth) {
        User vendor = userRepository.findByEmail(auth.getName()).orElseThrow();
        Product p = new Product();
        p.setName((String) body.get("name"));
        p.setDescription((String) body.get("description"));
        p.setPrice(new BigDecimal(body.get("price").toString()));
        p.setStock(Integer.parseInt(body.get("stock").toString()));
        p.setCategory((String) body.get("category"));
        p.setLocation((String) body.get("location"));
        p.setImageUrl((String) body.getOrDefault("imageUrl", ""));
        p.setVendor(vendor);
        productRepository.save(p);
        return ResponseEntity.ok(Map.of("message", "Product added", "id", p.getId()));
    }

    @PutMapping("/vendor/products/{id}")
    public ResponseEntity<?> updateProduct(@PathVariable Long id,
                                           @RequestBody Map<String, Object> body,
                                           Authentication auth) {
        User vendor = userRepository.findByEmail(auth.getName()).orElseThrow();
        Product p = productRepository.findById(id).orElseThrow();
        if (!p.getVendor().getId().equals(vendor.getId())) {
            return ResponseEntity.status(403).body(Map.of("error", "Forbidden"));
        }
        if (body.containsKey("name")) p.setName((String) body.get("name"));
        if (body.containsKey("description")) p.setDescription((String) body.get("description"));
        if (body.containsKey("price")) p.setPrice(new BigDecimal(body.get("price").toString()));
        if (body.containsKey("stock")) p.setStock(Integer.parseInt(body.get("stock").toString()));
        if (body.containsKey("category")) p.setCategory((String) body.get("category"));
        if (body.containsKey("location")) p.setLocation((String) body.get("location"));
        productRepository.save(p);
        return ResponseEntity.ok(Map.of("message", "Product updated"));
    }

    @DeleteMapping("/vendor/products/{id}")
    public ResponseEntity<?> deleteProduct(@PathVariable Long id, Authentication auth) {
        User vendor = userRepository.findByEmail(auth.getName()).orElseThrow();
        Product p = productRepository.findById(id).orElseThrow();
        if (!p.getVendor().getId().equals(vendor.getId())) {
            return ResponseEntity.status(403).body(Map.of("error", "Forbidden"));
        }
        p.setIsActive(false);
        productRepository.save(p);
        return ResponseEntity.ok(Map.of("message", "Product removed"));
    }

    // ---- ADMIN ENDPOINTS ----

    @GetMapping("/admin/products")
    public ResponseEntity<?> adminAllProducts() {
        return ResponseEntity.ok(productRepository.findAll()
                .stream().map(this::toMap).collect(Collectors.toList()));
    }

    // Helper
    private Map<String, Object> toMap(Product p) {
        Map<String, Object> m = new HashMap<>();
        m.put("id", p.getId());
        m.put("name", p.getName());
        m.put("description", p.getDescription());
        m.put("price", p.getPrice());
        m.put("stock", p.getStock());
        m.put("category", p.getCategory());
        m.put("location", p.getLocation());
        m.put("imageUrl", p.getImageUrl());
        m.put("isActive", p.getIsActive());
        m.put("createdAt", p.getCreatedAt());
        if (p.getVendor() != null) {
            Map<String, Object> vendor = new HashMap<>();
            vendor.put("id", p.getVendor().getId());
            vendor.put("name", p.getVendor().getName());
            vendor.put("city", p.getVendor().getCity());
            m.put("vendor", vendor);
        }
        return m;
    }
}
