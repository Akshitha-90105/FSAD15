package com.localmart.controller;

import com.localmart.model.CartItem;
import com.localmart.model.Product;
import com.localmart.model.User;
import com.localmart.repository.CartItemRepository;
import com.localmart.repository.ProductRepository;
import com.localmart.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/cart")
@CrossOrigin(origins = "*")
public class CartController {

    @Autowired private CartItemRepository cartItemRepository;
    @Autowired private ProductRepository productRepository;
    @Autowired private UserRepository userRepository;

    @GetMapping
    public ResponseEntity<?> getCart(Authentication auth) {
        User user = userRepository.findByEmail(auth.getName()).orElseThrow();
        List<CartItem> items = cartItemRepository.findByUser(user);
        return ResponseEntity.ok(items.stream().map(this::toMap).collect(Collectors.toList()));
    }

    @PostMapping("/add")
    public ResponseEntity<?> addToCart(@RequestBody Map<String, Object> body, Authentication auth) {
        User user = userRepository.findByEmail(auth.getName()).orElseThrow();
        Long productId = Long.parseLong(body.get("productId").toString());
        int quantity = Integer.parseInt(body.getOrDefault("quantity", "1").toString());

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        Optional<CartItem> existing = cartItemRepository.findByUserAndProductId(user, productId);
        if (existing.isPresent()) {
            CartItem item = existing.get();
            item.setQuantity(item.getQuantity() + quantity);
            cartItemRepository.save(item);
        } else {
            cartItemRepository.save(new CartItem(user, product, quantity));
        }
        return ResponseEntity.ok(Map.of("message", "Added to cart"));
    }

    @PutMapping("/{itemId}")
    public ResponseEntity<?> updateQuantity(@PathVariable Long itemId,
                                             @RequestBody Map<String, Object> body,
                                             Authentication auth) {
        CartItem item = cartItemRepository.findById(itemId).orElseThrow();
        int quantity = Integer.parseInt(body.get("quantity").toString());
        if (quantity <= 0) {
            cartItemRepository.delete(item);
            return ResponseEntity.ok(Map.of("message", "Item removed"));
        }
        item.setQuantity(quantity);
        cartItemRepository.save(item);
        return ResponseEntity.ok(Map.of("message", "Cart updated"));
    }

    @DeleteMapping("/{itemId}")
    public ResponseEntity<?> removeItem(@PathVariable Long itemId, Authentication auth) {
        cartItemRepository.deleteById(itemId);
        return ResponseEntity.ok(Map.of("message", "Item removed"));
    }

    @DeleteMapping("/clear")
    public ResponseEntity<?> clearCart(Authentication auth) {
        User user = userRepository.findByEmail(auth.getName()).orElseThrow();
        cartItemRepository.deleteByUser(user);
        return ResponseEntity.ok(Map.of("message", "Cart cleared"));
    }

    private Map<String, Object> toMap(CartItem item) {
        Map<String, Object> m = new HashMap<>();
        m.put("id", item.getId());
        m.put("quantity", item.getQuantity());
        Map<String, Object> p = new HashMap<>();
        p.put("id", item.getProduct().getId());
        p.put("name", item.getProduct().getName());
        p.put("price", item.getProduct().getPrice());
        p.put("imageUrl", item.getProduct().getImageUrl());
        p.put("stock", item.getProduct().getStock());
        m.put("product", p);
        BigDecimal subtotal = item.getProduct().getPrice()
                .multiply(new BigDecimal(item.getQuantity()));
        m.put("subtotal", subtotal);
        return m;
    }
}
