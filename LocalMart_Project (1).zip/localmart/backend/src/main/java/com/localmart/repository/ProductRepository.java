package com.localmart.repository;

import com.localmart.model.Product;
import com.localmart.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByIsActiveTrue();
    List<Product> findByVendorAndIsActiveTrue(User vendor);
    List<Product> findByCategoryAndIsActiveTrue(String category);

    @Query("SELECT p FROM Product p WHERE p.isActive = true AND " +
           "(LOWER(p.name) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(p.description) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    List<Product> searchProducts(String keyword);

    @Query("SELECT p FROM Product p WHERE p.isActive = true AND LOWER(p.location) LIKE LOWER(CONCAT('%', :city, '%'))")
    List<Product> findByCity(String city);
}
