package com.localmart.controller;

import com.localmart.model.*;
import com.localmart.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins = "*")
public class OrderController {

    @Autowired private OrderRepository orderRepository;
    @Autowired private OrderItemRepository orderItemRepository;
    @Autowired private CartItemRepository cartItemRepository;
    @Autowired private ProductRepository productRepository;
    @Autowired private UserRepository userRepository;

    @PostMapping("/place")
    public ResponseEntity<?> placeOrder(@RequestBody Map<String, Object> body, Authentication auth) {
        User customer = userRepository.findByEmail(auth.getName()).orElseThrow();
        List<CartItem> cartItems = cartItemRepository.findByUser(customer);

        if (cartItems.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Cart is empty"));
        }

        BigDecimal total = cartItems.stream()
                .map(ci -> ci.getProduct().getPrice().multiply(new BigDecimal(ci.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        Order order = new Order();
        order.setCustomer(customer);
        order.setTotalAmount(total);
        order.setShippingAddress((String) body.getOrDefault("shippingAddress", customer.getAddress()));
        order.setPaymentMethod((String) body.getOrDefault("paymentMethod", "COD"));
        orderRepository.save(order);

        List<OrderItem> orderItems = cartItems.stream().map(ci -> {
            OrderItem oi = new OrderItem(order, ci.getProduct(), ci.getQuantity(), ci.getProduct().getPrice());
            // Reduce stock
            Product p = ci.getProduct();
            p.setStock(Math.max(0, p.getStock() - ci.getQuantity()));
            productRepository.save(p);
            return oi;
        }).collect(Collectors.toList());

        orderItemRepository.saveAll(orderItems);
        cartItemRepository.deleteByUser(customer);

        return ResponseEntity.ok(Map.of("message", "Order placed successfully", "orderId", order.getId()));
    }

    @GetMapping("/my")
    public ResponseEntity<?> getMyOrders(Authentication auth) {
        User customer = userRepository.findByEmail(auth.getName()).orElseThrow();
        List<Order> orders = orderRepository.findByCustomerOrderByCreatedAtDesc(customer);
        return ResponseEntity.ok(orders.stream().map(this::toMap).collect(Collectors.toList()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getOrder(@PathVariable Long id, Authentication auth) {
        Order order = orderRepository.findById(id).orElseThrow();
        return ResponseEntity.ok(toMap(order));
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateStatus(@PathVariable Long id,
                                           @RequestBody Map<String, String> body) {
        Order order = orderRepository.findById(id).orElseThrow();
        order.setStatus(Order.Status.valueOf(body.get("status")));
        orderRepository.save(order);
        return ResponseEntity.ok(Map.of("message", "Status updated"));
    }

    @GetMapping("/admin/all")
    public ResponseEntity<?> getAllOrders() {
        return ResponseEntity.ok(orderRepository.findAllByOrderByCreatedAtDesc()
                .stream().map(this::toMap).collect(Collectors.toList()));
    }

    private Map<String, Object> toMap(Order o) {
        Map<String, Object> m = new HashMap<>();
        m.put("id", o.getId());
        m.put("status", o.getStatus());
        m.put("totalAmount", o.getTotalAmount());
        m.put("shippingAddress", o.getShippingAddress());
        m.put("paymentMethod", o.getPaymentMethod());
        m.put("createdAt", o.getCreatedAt());
        m.put("customerName", o.getCustomer().getName());
        if (o.getItems() != null) {
            m.put("items", o.getItems().stream().map(i -> {
                Map<String, Object> item = new HashMap<>();
                item.put("productName", i.getProduct().getName());
                item.put("quantity", i.getQuantity());
                item.put("unitPrice", i.getUnitPrice());
                item.put("subtotal", i.getUnitPrice().multiply(new BigDecimal(i.getQuantity())));
                return item;
            }).collect(Collectors.toList()));
        }
        return m;
    }
}
