package com.localmart.config;

import com.localmart.model.Product;
import com.localmart.model.User;
import com.localmart.repository.ProductRepository;
import com.localmart.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired private UserRepository userRepository;
    @Autowired private ProductRepository productRepository;
    @Autowired private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        // Admin
        if (!userRepository.existsByEmail("admin@localmart.com")) {
            User admin = new User("Admin", "admin@localmart.com",
                    passwordEncoder.encode("admin123"), User.Role.ADMIN);
            admin.setCity("Hyderabad");
            userRepository.save(admin);
        }

        // Vendors
        if (!userRepository.existsByEmail("ravi@localmart.com")) {
            User vendor1 = new User("Ravi Kumar", "ravi@localmart.com",
                    passwordEncoder.encode("vendor123"), User.Role.VENDOR);
            vendor1.setPhone("9876543210");
            vendor1.setCity("Hyderabad");
            vendor1.setAddress("Begumpet, Hyderabad");
            userRepository.save(vendor1);

            // Products for vendor1
            productRepository.save(new Product("Fresh Tomatoes", "Locally grown red tomatoes, pesticide-free",
                    new BigDecimal("30.00"), 100, "Vegetables", vendor1));
            productRepository.save(new Product("Organic Spinach", "Farm fresh organic spinach bundle",
                    new BigDecimal("25.00"), 60, "Vegetables", vendor1));
            productRepository.save(new Product("Basmati Rice (1kg)", "Premium quality basmati rice",
                    new BigDecimal("120.00"), 200, "Grains", vendor1));
        }

        if (!userRepository.existsByEmail("priya@localmart.com")) {
            User vendor2 = new User("Priya Reddy", "priya@localmart.com",
                    passwordEncoder.encode("vendor123"), User.Role.VENDOR);
            vendor2.setPhone("9988776655");
            vendor2.setCity("Hyderabad");
            vendor2.setAddress("Kukatpally, Hyderabad");
            userRepository.save(vendor2);

            productRepository.save(new Product("Handmade Soap", "Herbal handmade soap with neem and turmeric",
                    new BigDecimal("80.00"), 50, "Personal Care", vendor2));
            productRepository.save(new Product("Cotton Kurta", "Handwoven pure cotton kurta",
                    new BigDecimal("450.00"), 30, "Clothing", vendor2));
            productRepository.save(new Product("Earthen Pot", "Traditional clay water pot 5L",
                    new BigDecimal("150.00"), 20, "Kitchenware", vendor2));
        }

        // Customer
        if (!userRepository.existsByEmail("customer@localmart.com")) {
            User customer = new User("Anjali Singh", "customer@localmart.com",
                    passwordEncoder.encode("customer123"), User.Role.CUSTOMER);
            customer.setCity("Hyderabad");
            userRepository.save(customer);
        }

        System.out.println("=== LocalMart Data Initialized ===");
        System.out.println("Admin: admin@localmart.com / admin123");
        System.out.println("Vendor: ravi@localmart.com / vendor123");
        System.out.println("Customer: customer@localmart.com / customer123");
    }
}
