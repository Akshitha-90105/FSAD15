# 🛒 LocalMart – E-Commerce Platform for Local Vendors

**Team 15 | KLH University | FSAD Project**  
Dr. P. Srilatha | Department of Computer Science and Engineering

---

## 👥 Team Members
| Name | Roll Number |
|---|---|
| Akshitha Vobilisetty | 2420090105 |
| Reddam Srijitha | 2420030741 |
| Macharla Sai Srujan | 2420030256 |
| Dyarangula Dinesh Kumar | 2420030372 |

---

## 📌 Project Overview

LocalMart is a Java Full-Stack e-commerce platform dedicated to empowering local vendors by connecting them directly with nearby customers. It eliminates dependency on large commercial platforms and enables small businesses to list products, manage inventory, and receive orders online.

---

## 🏗️ Technology Stack

| Layer | Technology |
|---|---|
| Backend | Spring Boot 3.2, Spring Security, Spring Data JPA |
| Authentication | JWT (JSON Web Tokens) |
| Database | H2 (dev) / MySQL (production) |
| Frontend | HTML5, CSS3, Vanilla JavaScript |
| API | RESTful APIs |
| Build Tool | Maven |

---

## 📂 Project Structure

```
localmart/
├── backend/                          # Spring Boot Application
│   ├── pom.xml
│   └── src/main/java/com/localmart/
│       ├── LocalMartApplication.java
│       ├── config/
│       │   ├── SecurityConfig.java
│       │   ├── JwtUtil.java
│       │   ├── JwtRequestFilter.java
│       │   └── DataInitializer.java  ← Seeds demo data
│       ├── model/
│       │   ├── User.java             ← Roles: CUSTOMER, VENDOR, ADMIN
│       │   ├── Product.java
│       │   ├── CartItem.java
│       │   ├── Order.java
│       │   └── OrderItem.java
│       ├── repository/
│       │   ├── UserRepository.java
│       │   ├── ProductRepository.java
│       │   ├── CartItemRepository.java
│       │   ├── OrderRepository.java
│       │   └── OrderItemRepository.java
│       └── controller/
│           ├── AuthController.java    ← /api/auth/**
│           ├── ProductController.java ← /api/products/**
│           ├── CartController.java    ← /api/cart/**
│           ├── OrderController.java   ← /api/orders/**
│           └── AdminController.java   ← /api/admin/**
│
└── frontend/                         # Static HTML/CSS/JS
    ├── index.html                    ← Home Page
    ├── css/style.css
    ├── js/api.js                     ← API helper + auth utils
    └── pages/
        ├── login.html                ← Login Page
        ├── register.html             ← Registration Page
        ├── products.html             ← Product Listing + Search
        ├── product-detail.html       ← Product Detail Page
        ├── cart.html                 ← Shopping Cart + Checkout
        ├── orders.html               ← My Orders
        ├── vendor.html               ← Vendor Dashboard
        └── admin.html                ← Admin Panel
```

---

## 🚀 Getting Started

### Prerequisites
- Java 17+
- Maven 3.6+
- Any modern web browser
- (Optional) MySQL 8+ for production

### Step 1: Start the Backend

```bash
cd backend
mvn spring-boot:run
```

The server will start at **http://localhost:8080**

H2 Console (dev DB browser): http://localhost:8080/h2-console  
- JDBC URL: `jdbc:h2:mem:localmartdb`
- Username: `sa`, Password: *(blank)*

### Step 2: Open the Frontend

Open `frontend/index.html` in your browser directly, or use a local server:

```bash
# Using Python
cd frontend
python -m http.server 5500

# Then visit: http://localhost:5500
```

---

## 🔐 Demo Accounts (auto-seeded on startup)

| Role | Email | Password |
|---|---|---|
| 👤 Customer | customer@localmart.com | customer123 |
| 🏪 Vendor | ravi@localmart.com | vendor123 |
| 🏪 Vendor 2 | priya@localmart.com | vendor123 |
| ⚙️ Admin | admin@localmart.com | admin123 |

---

## 🔌 REST API Endpoints

### Authentication
```
POST /api/auth/register   – Register a new user
POST /api/auth/login      – Login and get JWT token
GET  /api/auth/me         – Get current user info
```

### Products (Public)
```
GET /api/products/public/all              – All active products
GET /api/products/public/{id}             – Product by ID
GET /api/products/public/search?keyword=  – Search products
GET /api/products/public/category/{cat}   – Filter by category
```

### Cart (Authenticated)
```
GET    /api/cart           – Get cart
POST   /api/cart/add       – Add item { productId, quantity }
PUT    /api/cart/{itemId}  – Update quantity
DELETE /api/cart/{itemId}  – Remove item
DELETE /api/cart/clear     – Clear cart
```

### Orders (Authenticated)
```
POST /api/orders/place     – Place order from cart
GET  /api/orders/my        – My orders
GET  /api/orders/{id}      – Order details
```

### Vendor (VENDOR role)
```
GET    /api/vendor/products      – Vendor's own products
POST   /api/vendor/products      – Add product
PUT    /api/vendor/products/{id} – Update product
DELETE /api/vendor/products/{id} – Deactivate product
```

### Admin (ADMIN role)
```
GET    /api/admin/stats         – Dashboard statistics
GET    /api/admin/users         – All users
DELETE /api/admin/users/{id}    – Delete user
GET    /api/admin/products       – All products
GET    /api/orders/admin/all     – All orders
PUT    /api/orders/{id}/status   – Update order status
```

---

## 🎯 Modules Implemented

| Module | Page | Description |
|---|---|---|
| Home Page | index.html | Hero, featured products, category filters |
| User Registration & Login | register.html / login.html | JWT auth, role-based |
| Product Listing Page | products.html | Search, filter by category |
| Product Details Page | product-detail.html | Full info, add-to-cart, buy now |
| Shopping Cart | cart.html | Qty management, subtotals |
| Order Placement Page | cart.html (checkout) | Address, payment method, COD |
| Vendor Dashboard | vendor.html | Add/edit/delete products |
| Admin Panel | admin.html | Users, products, order management |

---

## 🔮 Future Scope
- Mobile application (Android/iOS)
- Online payment gateway integration (Razorpay / UPI)
- Location-based vendor search with maps
- AI-based product recommendations
- Real-time order tracking
- Push notifications

---

## 📚 References
- Spring Boot: https://spring.io/projects/spring-boot
- Java Docs: https://docs.oracle.com/en/java/
- MySQL: https://dev.mysql.com/doc/
- W3Schools: https://www.w3schools.com/
- GeeksforGeeks: https://www.geeksforgeeks.org/
