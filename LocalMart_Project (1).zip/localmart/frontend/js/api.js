// ===========================
// LocalMart – API Helper
// ===========================

const API_BASE = 'http://localhost:8080/api';

const api = {
  // Auth helpers
  getToken: () => localStorage.getItem('lm_token'),
  getUser:  () => JSON.parse(localStorage.getItem('lm_user') || 'null'),
  isLoggedIn: () => !!localStorage.getItem('lm_token'),
  isVendor:  () => { const u = api.getUser(); return u && (u.role === 'VENDOR' || u.role === 'ROLE_VENDOR'); },
  isAdmin:   () => { const u = api.getUser(); return u && (u.role === 'ADMIN'  || u.role === 'ROLE_ADMIN');  },

  logout() {
    localStorage.removeItem('lm_token');
    localStorage.removeItem('lm_user');
    window.location.href = '/frontend/pages/login.html';
  },

  // Base request
  async request(path, options = {}) {
    const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
    const token = api.getToken();
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch(API_BASE + path, { ...options, headers });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || data.message || `Error ${res.status}`);
    return data;
  },

  get:    (path)         => api.request(path),
  post:   (path, body)   => api.request(path, { method: 'POST',   body: JSON.stringify(body) }),
  put:    (path, body)   => api.request(path, { method: 'PUT',    body: JSON.stringify(body) }),
  delete: (path)         => api.request(path, { method: 'DELETE' }),

  // Auth
  login:    (email, password) => api.post('/auth/login', { email, password }),
  register: (data)            => api.post('/auth/register', data),

  // Products (public)
  getProducts:   ()         => api.get('/products/public/all'),
  getProduct:    (id)       => api.get(`/products/public/${id}`),
  searchProducts:(kw)       => api.get(`/products/public/search?keyword=${encodeURIComponent(kw)}`),
  getByCategory: (cat)      => api.get(`/products/public/category/${encodeURIComponent(cat)}`),

  // Cart
  getCart:      ()          => api.get('/cart'),
  addToCart:    (productId, quantity = 1) => api.post('/cart/add', { productId, quantity }),
  updateCart:   (itemId, quantity)        => api.put(`/cart/${itemId}`, { quantity }),
  removeFromCart: (itemId)  => api.delete(`/cart/${itemId}`),
  clearCart:    ()          => api.delete('/cart/clear'),

  // Orders
  placeOrder:   (data)      => api.post('/orders/place', data),
  getMyOrders:  ()          => api.get('/orders/my'),
  getOrder:     (id)        => api.get(`/orders/${id}`),

  // Vendor
  getVendorProducts: ()     => api.get('/vendor/products'),
  addProduct:   (data)      => api.post('/vendor/products', data),
  updateProduct:(id, data)  => api.put(`/vendor/products/${id}`, data),
  deleteProduct:(id)        => api.delete(`/vendor/products/${id}`),

  // Admin
  getAdminStats: ()         => api.get('/admin/stats'),
  getAllUsers:   ()          => api.get('/admin/users'),
  getAllOrders:  ()          => api.get('/orders/admin/all'),
  updateOrderStatus: (id, status) => api.put(`/orders/${id}/status`, { status }),
};

// Nav cart badge update
async function updateCartBadge() {
  if (!api.isLoggedIn()) return;
  try {
    const items = await api.getCart();
    const badge = document.getElementById('cart-count');
    if (badge) badge.textContent = items.length > 0 ? items.length : '';
  } catch {}
}

// Render nav based on auth state
function renderNav() {
  const user = api.getUser();
  const navAuth = document.getElementById('nav-auth');
  if (!navAuth) return;
  if (!user) {
    navAuth.innerHTML = `
      <a href="/frontend/pages/login.html">Login</a>
      <a href="/frontend/pages/register.html" class="btn-nav">Sign Up</a>`;
  } else {
    const cartLink = (!api.isVendor() && !api.isAdmin())
      ? `<a href="/frontend/pages/cart.html">🛒 Cart <span class="cart-badge" id="cart-count"></span></a>` : '';
    const dashLink = api.isAdmin()
      ? `<a href="/frontend/pages/admin.html">⚙️ Admin</a>`
      : api.isVendor()
      ? `<a href="/frontend/pages/vendor.html">📦 Dashboard</a>`
      : `<a href="/frontend/pages/orders.html">📋 Orders</a>`;
    navAuth.innerHTML = `
      ${cartLink}
      ${dashLink}
      <span style="color:rgba(255,255,255,0.6);font-size:0.85rem">Hi, ${user.name.split(' ')[0]}</span>
      <a href="#" onclick="api.logout()" class="btn-nav">Logout</a>`;
    updateCartBadge();
  }
}

// Toast notification
function toast(msg, type = 'success') {
  let t = document.getElementById('toast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'toast';
    t.style.cssText = 'position:fixed;bottom:1.5rem;right:1.5rem;padding:0.75rem 1.2rem;border-radius:8px;font-size:0.92rem;font-weight:600;z-index:9999;max-width:320px;box-shadow:0 4px 16px rgba(0,0,0,0.15);transition:opacity 0.3s';
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.style.background = type === 'success' ? '#2e7d32' : type === 'error' ? '#c62828' : '#1565c0';
  t.style.color = 'white';
  t.style.opacity = '1';
  clearTimeout(t._timeout);
  t._timeout = setTimeout(() => { t.style.opacity = '0'; }, 3000);
}

// Require auth redirect
function requireAuth(role) {
  if (!api.isLoggedIn()) { window.location.href = '/frontend/pages/login.html'; return false; }
  if (role === 'VENDOR' && !api.isVendor()) { window.location.href = '/frontend/index.html'; return false; }
  if (role === 'ADMIN'  && !api.isAdmin())  { window.location.href = '/frontend/index.html'; return false; }
  return true;
}

// Category emoji map
const CATEGORY_ICONS = {
  'Vegetables': '🥦', 'Fruits': '🍎', 'Grains': '🌾', 'Dairy': '🥛',
  'Meat': '🥩', 'Seafood': '🐟', 'Bakery': '🍞', 'Clothing': '👗',
  'Kitchenware': '🍳', 'Personal Care': '🧴', 'Electronics': '📱',
  'Handicrafts': '🎨', 'Default': '📦'
};
function getCategoryIcon(cat) { return CATEGORY_ICONS[cat] || CATEGORY_ICONS['Default']; }

// Shared navbar HTML
const NAV_HTML = `
<nav class="navbar">
  <a href="/frontend/index.html" class="logo">Local<span>Mart</span></a>
  <div class="nav-links">
    <a href="/frontend/index.html">Home</a>
    <a href="/frontend/pages/products.html">Products</a>
    <div id="nav-auth"></div>
  </div>
</nav>`;

document.addEventListener('DOMContentLoaded', () => {
  const navPlaceholder = document.getElementById('navbar');
  if (navPlaceholder) { navPlaceholder.innerHTML = NAV_HTML; renderNav(); }
});
